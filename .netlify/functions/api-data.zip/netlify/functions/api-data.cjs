var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api-data.js
var api_data_exports = {};
__export(api_data_exports, {
  config: () => config,
  default: () => api_data_default
});
module.exports = __toCommonJS(api_data_exports);
var import_blobs2 = require("@netlify/blobs");

// netlify/functions/_lib.js
var import_blobs = require("@netlify/blobs");
var GUEST_WRITABLE = /* @__PURE__ */ new Set([
  "blueprintstudio-forum-2026",
  "blueprintstudio-notes-2026",
  "blueprintstudio-chat-v2",
  "blueprintstudio-discover-v1",
  "blueprintstudio-logs-v1"
  /* 前端错误日志匿名上报 */
]);
var ADMIN_ONLY = /* @__PURE__ */ new Set([
  "blueprintstudio-users-v2",
  "blueprintstudio-announce-v2"
]);
function json(body, status, headers) {
  const h = Object.assign({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  }, headers || {});
  return new Response(JSON.stringify(body), { status: status || 200, headers: h });
}
function preflight() {
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  } });
}
function clientIP(req) {
  const h = req.headers;
  return (h.get("x-nf-client-connection-ip") || h.get("x-forwarded-for") || "0.0.0.0").split(",")[0].trim();
}
var buckets = /* @__PURE__ */ new Map();
function rateLimit(name, ip, limit, windowMs) {
  const now = Date.now();
  const key = name + "|" + ip;
  let b = buckets.get(key);
  if (!b || now > b.until) {
    b = { n: 0, until: now + windowMs };
    buckets.set(key, b);
  }
  b.n++;
  if (buckets.size > 5e3) buckets.clear();
  return b.n <= limit;
}
var _secret = null;
async function getSecret() {
  if (_secret) return _secret;
  const meta = (0, import_blobs.getStore)("meta");
  let s = await meta.get("__api_secret");
  if (!s) {
    const buf = new Uint8Array(32);
    crypto.getRandomValues(buf);
    s = Array.from(buf).map((x) => x.toString(16).padStart(2, "0")).join("");
    await meta.set("__api_secret", s);
  }
  _secret = s;
  return s;
}
function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return decodeURIComponent(escape(atob(s)));
}
async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function verifyToken(req) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  const dot = m[1].lastIndexOf(".");
  if (dot < 1) return null;
  const body = m[1].slice(0, dot), sig = m[1].slice(dot + 1);
  const secret = await getSecret();
  if (!safeEq(sig, await hmacHex(secret, body))) return null;
  try {
    const obj = JSON.parse(unb64url(body));
    if (obj.exp && Date.now() > obj.exp) return null;
    return obj;
  } catch (e) {
    return null;
  }
}

// netlify/functions/api-data.js
var config = { path: "/api/data" };
var store = () => (0, import_blobs2.getStore)("data");
var api_data_default = async (req) => {
  if (req.method === "OPTIONS") return preflight();
  if (req.method === "GET") {
    const key2 = new URL(req.url).searchParams.get("key") || "";
    if (!/^blueprintstudio-[a-z0-9-]+$/.test(key2)) return json({ ok: false, msg: "key \u4E0D\u5408\u6CD5" }, 400);
    const raw = await store().get(key2);
    return new Response(raw === null ? "{}" : raw, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
  if (req.method !== "POST") return json({ ok: false, msg: "\u53EA\u652F\u6301 GET/POST" }, 405);
  const ip = clientIP(req);
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return json({ ok: false, msg: "JSON \u89E3\u6790\u5931\u8D25" }, 400);
  }
  const key = body.key || "";
  if (!/^blueprintstudio-[a-z0-9-]+$/.test(key)) return json({ ok: false, msg: "key \u4E0D\u5408\u6CD5" }, 400);
  if (key === "blueprintstudio-users-v2") return json({ ok: false, msg: "\u7528\u6237\u5E93\u53EA\u80FD\u901A\u8FC7\u8D26\u53F7\u63A5\u53E3\u64CD\u4F5C" }, 403);
  const tok = await verifyToken(req);
  if (ADMIN_ONLY.has(key) && (!tok || !tok.admin)) {
    return json({ ok: false, msg: "\u9700\u8981\u7BA1\u7406\u5458\u6743\u9650" }, 403);
  }
  if (!tok) {
    if (!GUEST_WRITABLE.has(key)) return json({ ok: false, msg: "\u8BE5\u5E93\u9700\u8981\u767B\u5F55\u540E\u64CD\u4F5C" }, 401);
    if (!rateLimit("gw", ip, 12, 60 * 1e3)) return json({ ok: false, msg: "\u64CD\u4F5C\u592A\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" }, 429);
  } else {
    if (!rateLimit("dw", ip, 60, 60 * 1e3)) return json({ ok: false, msg: "\u64CD\u4F5C\u592A\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" }, 429);
  }
  const data = typeof body.data === "string" ? body.data : JSON.stringify(body.data);
  if (data.length > 8 * 1024 * 1024) return json({ ok: false, msg: "\u6570\u636E\u8FC7\u5927\uFF08\u4E0A\u9650 8MB\uFF09" }, 413);
  await store().set(key, data);
  return json({ ok: true });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
