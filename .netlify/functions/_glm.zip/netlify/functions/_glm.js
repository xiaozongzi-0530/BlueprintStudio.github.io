var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_glm.js
var glm_exports = {};
__export(glm_exports, {
  GLM_URL: () => GLM_URL,
  MODEL: () => MODEL,
  judge: () => judge
});
module.exports = __toCommonJS(glm_exports);
var GLM_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions";
var MODEL = "glm-4-flash";
var RULES = `\u8FDD\u89C4\u5224\u5B9A\u6807\u51C6\uFF1A
1. \u8272\u60C5\u4F4E\u4FD7\u3001\u6027\u6697\u793A\u5185\u5BB9
2. \u6D89\u653F\u654F\u611F\u3001\u5371\u5BB3\u56FD\u5BB6\u5B89\u5168\u6216\u793E\u4F1A\u7A33\u5B9A\u7684\u5185\u5BB9
3. \u66B4\u529B\u8840\u8165\u3001\u6050\u5413\u5A01\u80C1\u3001\u6559\u5506\u81EA\u6B8B
4. \u8D4C\u535A\u3001\u6BD2\u54C1\u3001\u67AA\u652F\u7B49\u8FDD\u7981\u54C1\u76F8\u5173
5. \u8BC8\u9A97\u3001\u9493\u9C7C\u3001\u5237\u5355\u3001\u4F20\u9500\u3001\u4EE3\u8003\u4EE3\u5199
6. \u6076\u610F\u5E7F\u544A\u3001\u4E0E\u793E\u533A\u65E0\u5173\u7684\u8425\u9500\u5F15\u6D41
7. \u4FAE\u8FB1\u8C29\u9A82\u3001\u4EBA\u8EAB\u653B\u51FB\u3001\u5730\u57DF\u6216\u7FA4\u4F53\u6B67\u89C6
8. \u6CC4\u9732\u4ED6\u4EBA\u9690\u79C1\uFF08\u624B\u673A\u53F7\u3001\u4F4F\u5740\u3001\u8EAB\u4EFD\u8BC1\u3001\u5BC6\u7801\u7B49\uFF09
9. \u6728\u9A6C\u75C5\u6BD2\u3001\u76D7\u7248\u7834\u89E3\u3001\u5916\u6302\u4F5C\u5F0A
10. \u672A\u6210\u5E74\u4EBA\u76F8\u5173\u7684\u4E0D\u826F\u5185\u5BB9

\u4EE5\u4E0B\u5185\u5BB9\u4E00\u5F8B\u89C6\u4E3A\u6B63\u5E38\uFF0C\u4E0D\u8981\u8BEF\u5224\uFF1A
- \u6280\u672F\u8BA8\u8BBA\u3001\u4EE3\u7801\u3001\u62A5\u9519\u6C42\u52A9\u3001\u5F00\u6E90\u9879\u76EE\u4ECB\u7ECD
- \u65E5\u5E38\u4EA4\u6D41\u3001\u5F00\u73A9\u7B11\uFF08\u65E0\u4EBA\u8EAB\u653B\u51FB\uFF09\u3001\u8868\u60C5
- \u7AD9\u70B9\u529F\u80FD\u53CD\u9988\u3001bug \u62A5\u544A`;
var PUBLISH_PROMPT = `\u4F60\u662F "BlueprintStudio" \u7A0B\u5E8F\u5458\u793E\u533A\u7684\u5185\u5BB9\u5BA1\u6838\u5458\u3002\u5224\u65AD\u63D0\u4EA4\u7684\u5185\u5BB9\u662F\u5426\u8FDD\u89C4\u3002

${RULES}

\u53EA\u8F93\u51FA JSON\uFF0C\u7981\u6B62\u8F93\u51FA\u5176\u4ED6\u4EFB\u4F55\u6587\u5B57\uFF1A
{"clean": true\u6216false, "category": "\u8FDD\u89C4\u7C7B\u522B\u82F1\u6587\u6807\u8BC6\uFF0C\u6B63\u5E38\u5219\u7559\u7A7A", "reason": "\u7ED9\u7528\u6237\u770B\u7684\u7B80\u77ED\u4E2D\u6587\u8BF4\u660E\uFF0C\u6B63\u5E38\u65F6\u586B\uFF1A\u5185\u5BB9\u6B63\u5E38"}`;
var REPORT_PROMPT = `\u4F60\u662F "BlueprintStudio" \u7A0B\u5E8F\u5458\u793E\u533A\u7684\u4E3E\u62A5\u5BA1\u6838\u5458\u3002\u7528\u6237\u4E3E\u62A5\u4E86\u4E00\u6BB5\u5185\u5BB9\uFF0C\u8BF7\u7ED3\u5408\u4E3E\u62A5\u7406\u7531\u5224\u65AD\u88AB\u4E3E\u62A5\u5185\u5BB9\u672C\u8EAB\u662F\u5426\u8FDD\u89C4\u3002

${RULES}

\u6CE8\u610F\uFF1A
- \u4F60\u5224\u65AD\u7684\u662F"\u88AB\u4E3E\u62A5\u5185\u5BB9"\u662F\u5426\u771F\u7684\u8FDD\u89C4\uFF0C\u4E3E\u62A5\u7406\u7531\u672C\u8EAB\u53EF\u80FD\u6076\u610F\u6216\u5938\u5F20\uFF0C\u4EC5\u4F9B\u53C2\u8003
- \u7406\u7531\u4E0E\u5185\u5BB9\u5BF9\u4E0D\u4E0A\u3001\u6216\u5185\u5BB9\u5176\u5B9E\u6B63\u5E38\u65F6\uFF0C\u5E94\u5224\u4E0D\u8FDD\u89C4

\u53EA\u8F93\u51FA JSON\uFF0C\u7981\u6B62\u8F93\u51FA\u5176\u4ED6\u4EFB\u4F55\u6587\u5B57\uFF1A
{"violates": true\u6216false, "category": "\u8FDD\u89C4\u7C7B\u522B\u82F1\u6587\u6807\u8BC6\uFF0C\u4E0D\u8FDD\u89C4\u5219\u7559\u7A7A", "reason": "\u7ED9\u7BA1\u7406\u5458\u770B\u7684\u4E2D\u6587\u5206\u6790\uFF0C\u8BF4\u660E\u4E3A\u4EC0\u4E48\u8FDD\u89C4/\u4E0D\u8FDD\u89C4"}`;
function clamp(s, n) {
  s = String(s || "");
  return s.length > n ? s.slice(0, n) : s;
}
async function judge(apiKey, mode, text, reportReason) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2e4);
  try {
    const userMsg = mode === "report" ? "\u4E3E\u62A5\u7406\u7531\uFF1A\n" + clamp(reportReason, 500) + "\n\n\u88AB\u4E3E\u62A5\u5185\u5BB9\uFF1A\n" + clamp(text, 6e3) : "\u5F85\u5BA1\u6838\u5185\u5BB9\uFF1A\n" + clamp(text, 6e3);
    const r = await fetch(GLM_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: mode === "report" ? REPORT_PROMPT : PUBLISH_PROMPT },
          { role: "user", content: userMsg }
        ],
        temperature: 0.05,
        max_tokens: 300
      }),
      signal: ctrl.signal
    });
    if (!r.ok) throw new Error("GLM HTTP " + r.status);
    const data = await r.json();
    const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content || "";
    const m = content.match(/\{[\s\S]*\}/);
    if (!m) throw new Error("GLM \u8FD4\u56DE\u65E0\u6CD5\u89E3\u6790");
    const v = JSON.parse(m[0]);
    if (mode === "report") {
      return {
        violates: v.violates === true,
        category: clamp(v.category || "", 40),
        reason: clamp(v.reason || "", 200)
      };
    }
    return {
      clean: v.clean !== false,
      category: clamp(v.category || "", 40),
      reason: clamp(v.reason || "", 120)
    };
  } finally {
    clearTimeout(timer);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GLM_URL,
  MODEL,
  judge
});
