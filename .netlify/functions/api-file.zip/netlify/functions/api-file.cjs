var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api-file.js
var api_file_exports = {};
__export(api_file_exports, {
  config: () => config,
  default: () => api_file_default
});
module.exports = __toCommonJS(api_file_exports);
var import_blobs2 = require("@netlify/blobs");

// netlify/functions/_lib.js
var import_blobs = require("@netlify/blobs");
function json(body, status, headers) {
  const h = Object.assign({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  }, headers || {});
  return new Response(JSON.stringify(body), { status: status || 200, headers: h });
}
function preflight() {
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  } });
}
function clientIP(req) {
  const h = req.headers;
  return (h.get("x-nf-client-connection-ip") || h.get("x-forwarded-for") || "0.0.0.0").split(",")[0].trim();
}
var buckets = /* @__PURE__ */ new Map();
function rateLimit(name, ip, limit, windowMs) {
  const now = Date.now();
  const key = name + "|" + ip;
  let b = buckets.get(key);
  if (!b || now > b.until) {
    b = { n: 0, until: now + windowMs };
    buckets.set(key, b);
  }
  b.n++;
  if (buckets.size > 5e3) buckets.clear();
  return b.n <= limit;
}
var _secret = null;
async function getSecret() {
  if (_secret) return _secret;
  const meta = (0, import_blobs.getStore)("meta");
  let s = await meta.get("__api_secret");
  if (!s) {
    const buf = new Uint8Array(32);
    crypto.getRandomValues(buf);
    s = Array.from(buf).map((x) => x.toString(16).padStart(2, "0")).join("");
    await meta.set("__api_secret", s);
  }
  _secret = s;
  return s;
}
function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return decodeURIComponent(escape(atob(s)));
}
async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function verifyToken(req) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  const dot = m[1].lastIndexOf(".");
  if (dot < 1) return null;
  const body = m[1].slice(0, dot), sig = m[1].slice(dot + 1);
  const secret = await getSecret();
  if (!safeEq(sig, await hmacHex(secret, body))) return null;
  try {
    const obj = JSON.parse(unb64url(body));
    if (obj.exp && Date.now() > obj.exp) return null;
    return obj;
  } catch (e) {
    return null;
  }
}

// netlify/functions/api-file.js
var config = { path: "/api/file" };
var store = () => (0, import_blobs2.getStore)("files");
var MAX = 5 * 1024 * 1024;
var api_file_default = async (req) => {
  if (req.method === "OPTIONS") return preflight();
  if (req.method === "GET") {
    const id2 = new URL(req.url).searchParams.get("id") || "";
    if (!/^[a-f0-9]{24}$/.test(id2)) return json({ ok: false, msg: "id \u4E0D\u5408\u6CD5" }, 400);
    const buf = await store().get(id2, { type: "arrayBuffer" });
    if (!buf) return json({ ok: false, msg: "\u9644\u4EF6\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664" }, 404);
    const meta = await store().getWithMetadata(id2);
    const type = meta && meta.metadata && meta.metadata.type || "application/octet-stream";
    const name = meta && meta.metadata && meta.metadata.name || "attachment";
    return new Response(buf, {
      status: 200,
      headers: {
        "Content-Type": type,
        "Content-Disposition": "inline; filename*=UTF-8''" + encodeURIComponent(name),
        "Cache-Control": "public, max-age=31536000, immutable",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
  if (req.method !== "POST") return json({ ok: false, msg: "\u53EA\u652F\u6301 GET/POST" }, 405);
  const ip = clientIP(req);
  const tok = await verifyToken(req);
  const limit = tok ? 60 : 20;
  if (!rateLimit(tok ? "fu" : "fg", ip, limit, 3600 * 1e3)) {
    return json({ ok: false, msg: "\u4E0A\u4F20\u592A\u9891\u7E41\uFF08\u6BCF\u5C0F\u65F6 " + limit + " \u6B21\uFF09\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" }, 429);
  }
  let form;
  try {
    form = await req.formData();
  } catch (e) {
    return json({ ok: false, msg: "\u9700\u8981 multipart/form-data" }, 400);
  }
  const file = form.get("file");
  if (!file || typeof file === "string") return json({ ok: false, msg: "\u7F3A\u5C11 file \u5B57\u6BB5" }, 400);
  if (file.size > MAX) return json({ ok: false, msg: "\u6587\u4EF6\u8D85\u8FC7 5MB \u4E0A\u9650" }, 413);
  if (file.size === 0) return json({ ok: false, msg: "\u7A7A\u6587\u4EF6" }, 400);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const rnd = new Uint8Array(12);
  crypto.getRandomValues(rnd);
  const id = Array.from(rnd).map((x) => x.toString(16).padStart(2, "0")).join("");
  await store().set(id, bytes, {
    metadata: {
      name: String(file.name || "attachment").slice(0, 120),
      type: String(file.type || "application/octet-stream").slice(0, 100),
      size: file.size,
      by: tok && tok.email || "ip:" + ip,
      at: (/* @__PURE__ */ new Date()).toISOString()
    }
  });
  return json({ ok: true, id, size: file.size, name: file.name });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
