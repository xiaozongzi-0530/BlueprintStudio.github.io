var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api-migrate.js
var api_migrate_exports = {};
__export(api_migrate_exports, {
  config: () => config,
  default: () => api_migrate_default
});
module.exports = __toCommonJS(api_migrate_exports);
var import_blobs2 = require("@netlify/blobs");

// netlify/functions/_lib.js
var import_blobs = require("@netlify/blobs");
function json(body, status, headers) {
  const h = Object.assign({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  }, headers || {});
  return new Response(JSON.stringify(body), { status: status || 200, headers: h });
}
function preflight() {
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  } });
}
var usersStore = () => (0, import_blobs.getStore)("users");
async function putUsersRaw(db) {
  await usersStore().set("__all", JSON.stringify(db));
}

// netlify/functions/api-migrate.js
var config = { path: "/api/migrate" };
var KEYS = [
  "blueprintstudio-users-v2",
  "blueprintstudio-announce-v2",
  "blueprintstudio-forum-2026",
  "blueprintstudio-notes-2026",
  "blueprintstudio-chat-v2",
  "blueprintstudio-discover-v1"
];
var api_migrate_default = async (req) => {
  if (req.method === "OPTIONS") return preflight();
  if (req.method !== "GET") return json({ ok: false, msg: "\u53EA\u652F\u6301 GET" }, 405);
  const data = (0, import_blobs2.getStore)("data");
  const result = {};
  for (const key of KEYS) {
    try {
      const exists = await data.get(key);
      if (exists !== null) {
        result[key] = "skipped\uFF08\u5DF2\u6709\u6570\u636E\uFF09";
        continue;
      }
      const r = await fetch("https://textdb.dev/api/data/" + key, { cache: "no-store" });
      if (!r.ok) {
        result[key] = "textdb \u8BFB\u53D6\u5931\u8D25 HTTP " + r.status;
        continue;
      }
      const text = await r.text();
      if (!text || text === "null") {
        result[key] = "textdb \u4E3A\u7A7A\uFF0C\u8DF3\u8FC7";
        continue;
      }
      JSON.parse(text);
      if (key === "blueprintstudio-users-v2") {
        await putUsersRaw(JSON.parse(text));
        const masked = JSON.parse(text);
        let removed = 0;
        Object.keys(masked.users || {}).forEach((e) => {
          if (masked.users[e] && masked.users[e].hash) {
            delete masked.users[e].hash;
            removed++;
          }
        });
        await fetch("https://textdb.dev/api/data/" + key, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify(masked)
        });
        result[key] = "\u5BFC\u5165\u5B8C\u6210\uFF0Ctextdb \u539F\u5E93\u5DF2\u8131\u654F " + removed + " \u4E2A\u5BC6\u7801 hash";
      } else {
        await data.set(key, text);
        result[key] = "\u5BFC\u5165\u5B8C\u6210\uFF08" + text.length + " \u5B57\u8282\uFF09";
      }
    } catch (e) {
      result[key] = "\u5931\u8D25\uFF1A" + (e && e.message);
    }
  }
  return json({ ok: true, result });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
