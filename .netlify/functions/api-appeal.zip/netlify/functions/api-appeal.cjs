var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api-appeal.js
var api_appeal_exports = {};
__export(api_appeal_exports, {
  config: () => config,
  default: () => api_appeal_default
});
module.exports = __toCommonJS(api_appeal_exports);

// netlify/functions/_lib.js
var import_blobs = require("@netlify/blobs");
function json(body, status, headers) {
  const h = Object.assign({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  }, headers || {});
  return new Response(JSON.stringify(body), { status: status || 200, headers: h });
}
function preflight() {
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  } });
}
function clientIP(req) {
  const h = req.headers;
  return (h.get("x-nf-client-connection-ip") || h.get("x-forwarded-for") || "0.0.0.0").split(",")[0].trim();
}
var buckets = /* @__PURE__ */ new Map();
function rateLimit(name, ip, limit, windowMs) {
  const now = Date.now();
  const key = name + "|" + ip;
  let b = buckets.get(key);
  if (!b || now > b.until) {
    b = { n: 0, until: now + windowMs };
    buckets.set(key, b);
  }
  b.n++;
  if (buckets.size > 5e3) buckets.clear();
  return b.n <= limit;
}
var _secret = null;
async function getSecret() {
  if (_secret) return _secret;
  const meta = (0, import_blobs.getStore)("meta");
  let s = await meta.get("__api_secret");
  if (!s) {
    const buf = new Uint8Array(32);
    crypto.getRandomValues(buf);
    s = Array.from(buf).map((x) => x.toString(16).padStart(2, "0")).join("");
    await meta.set("__api_secret", s);
  }
  _secret = s;
  return s;
}
function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return decodeURIComponent(escape(atob(s)));
}
async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function verifyToken(req) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  const dot = m[1].lastIndexOf(".");
  if (dot < 1) return null;
  const body = m[1].slice(0, dot), sig = m[1].slice(dot + 1);
  const secret = await getSecret();
  if (!safeEq(sig, await hmacHex(secret, body))) return null;
  try {
    const obj = JSON.parse(unb64url(body));
    if (obj.exp && Date.now() > obj.exp) return null;
    return obj;
  } catch (e) {
    return null;
  }
}

// netlify/functions/api-appeal.js
var config = { path: "/api/appeal" };
var MAX_ITEMS = 200;
var store = () => (0, import_blobs.getStore)("appeals");
async function readAll() {
  const s = await store().get("list");
  if (!s) return [];
  try {
    const db = JSON.parse(s);
    return Array.isArray(db.items) ? db.items : [];
  } catch (e) {
    return [];
  }
}
async function writeAll(items) {
  await store().set("list", JSON.stringify({ items: items.slice(-MAX_ITEMS) }));
}
function clamp(s, n) {
  s = String(s == null ? "" : s);
  return s.length > n ? s.slice(0, n) : s;
}
var api_appeal_default = async (req) => {
  if (req.method === "OPTIONS") return preflight();
  const ip = clientIP(req);
  if (req.method === "GET") {
    const tok = await verifyToken(req);
    if (!tok || !tok.admin) return json({ ok: false, msg: "\u9700\u8981\u7BA1\u7406\u5458\u8EAB\u4EFD" }, 403);
    const items2 = await readAll();
    items2.reverse();
    return json({ ok: true, items: items2, pending: items2.filter((i) => i.status === "pending").length });
  }
  if (req.method !== "POST") return json({ ok: false, msg: "\u53EA\u652F\u6301 GET/POST" }, 405);
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return json({ ok: false, msg: "JSON \u89E3\u6790\u5931\u8D25" }, 400);
  }
  if (body.action === "resolve") {
    const tok = await verifyToken(req);
    if (!tok || !tok.admin) return json({ ok: false, msg: "\u9700\u8981\u7BA1\u7406\u5458\u8EAB\u4EFD" }, 403);
    const items2 = await readAll();
    const it = items2.find((i) => i.id === body.id);
    if (!it) return json({ ok: false, msg: "\u7533\u8BC9\u4E0D\u5B58\u5728" }, 404);
    it.status = "done";
    it.outcome = clamp(body.outcome || "\u5DF2\u5904\u7406", 40);
    it.handledBy = tok.email;
    it.handledAt = (/* @__PURE__ */ new Date()).toISOString();
    await writeAll(items2);
    return json({ ok: true });
  }
  if (!rateLimit("appeal", ip, 5, 3600 * 1e3)) {
    return json({ ok: false, msg: "\u7533\u8BC9\u63D0\u4EA4\u592A\u9891\u7E41\uFF0C\u8BF7\u4E00\u5C0F\u65F6\u540E\u518D\u8BD5" }, 429);
  }
  const kind = clamp(body.kind, 20);
  const content = clamp(body.content, 6e3);
  const aiReason = clamp(body.aiReason, 200);
  if (!content.trim()) return json({ ok: false, msg: "\u7533\u8BC9\u5185\u5BB9\u4E3A\u7A7A" }, 400);
  const items = await readAll();
  items.push({
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    kind: kind || "unknown",
    content,
    aiReason,
    who: clamp(body.who, 120),
    ip,
    status: "pending",
    t: (/* @__PURE__ */ new Date()).toISOString()
  });
  await writeAll(items);
  return json({ ok: true, msg: "\u7533\u8BC9\u5DF2\u63D0\u4EA4\uFF0C\u7BA1\u7406\u5458\u5C06\u5728 3 \u4E2A\u5DE5\u4F5C\u65E5\u5185\u4EBA\u5DE5\u5904\u7406" });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
