var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api-auth.js
var api_auth_exports = {};
__export(api_auth_exports, {
  config: () => config,
  default: () => api_auth_default
});
module.exports = __toCommonJS(api_auth_exports);

// netlify/functions/_lib.js
var import_blobs = require("@netlify/blobs");
var ADMIN_EMAIL = "zhouxinyuan0530@qq.com";
function json(body, status, headers) {
  const h = Object.assign({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  }, headers || {});
  return new Response(JSON.stringify(body), { status: status || 200, headers: h });
}
function preflight() {
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  } });
}
function clientIP(req) {
  const h = req.headers;
  return (h.get("x-nf-client-connection-ip") || h.get("x-forwarded-for") || "0.0.0.0").split(",")[0].trim();
}
var buckets = /* @__PURE__ */ new Map();
function rateLimit(name, ip, limit, windowMs) {
  const now = Date.now();
  const key = name + "|" + ip;
  let b = buckets.get(key);
  if (!b || now > b.until) {
    b = { n: 0, until: now + windowMs };
    buckets.set(key, b);
  }
  b.n++;
  if (buckets.size > 5e3) buckets.clear();
  return b.n <= limit;
}
var _secret = null;
async function getSecret() {
  if (_secret) return _secret;
  const meta = (0, import_blobs.getStore)("meta");
  let s = await meta.get("__api_secret");
  if (!s) {
    const buf = new Uint8Array(32);
    crypto.getRandomValues(buf);
    s = Array.from(buf).map((x) => x.toString(16).padStart(2, "0")).join("");
    await meta.set("__api_secret", s);
  }
  _secret = s;
  return s;
}
function b64url(s) {
  return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return decodeURIComponent(escape(atob(s)));
}
async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function signToken(payload) {
  const secret = await getSecret();
  const body = b64url(JSON.stringify(payload));
  return body + "." + await hmacHex(secret, body);
}
async function verifyToken(req) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  const dot = m[1].lastIndexOf(".");
  if (dot < 1) return null;
  const body = m[1].slice(0, dot), sig = m[1].slice(dot + 1);
  const secret = await getSecret();
  if (!safeEq(sig, await hmacHex(secret, body))) return null;
  try {
    const obj = JSON.parse(unb64url(body));
    if (obj.exp && Date.now() > obj.exp) return null;
    return obj;
  } catch (e) {
    return null;
  }
}
var usersStore = () => (0, import_blobs.getStore)("users");
async function getUsersRaw() {
  const s = await usersStore().get("__all");
  if (!s) return { users: {} };
  try {
    return JSON.parse(s);
  } catch (e) {
    return { users: {} };
  }
}
async function putUsersRaw(db) {
  await usersStore().set("__all", JSON.stringify(db));
}
function stripUsers(db) {
  const out = { users: {} };
  const src = db && db.users || {};
  Object.keys(src).forEach((email) => {
    const u = Object.assign({}, src[email]);
    delete u.hash;
    out.users[email] = u;
  });
  return out;
}
async function issueToken(email, rec) {
  return signToken({
    email,
    uid: rec.uid || "",
    admin: email === ADMIN_EMAIL,
    exp: Date.now() + 7 * 24 * 3600 * 1e3
  });
}

// netlify/functions/api-auth.js
var config = { path: "/api/auth" };
function bad(msg, status) {
  return json({ ok: false, msg: msg || "\u8BF7\u6C42\u4E0D\u5408\u6CD5" }, status || 400);
}
function stripUser(rec) {
  const c = Object.assign({}, rec || {});
  delete c.hash;
  return c;
}
var api_auth_default = async (req) => {
  if (req.method === "OPTIONS") return preflight();
  if (req.method !== "POST") return bad("\u53EA\u652F\u6301 POST", 405);
  const ip = clientIP(req);
  if (!rateLimit("auth", ip, 60, 60 * 1e3)) return bad("\u64CD\u4F5C\u592A\u9891\u7E41\uFF0C\u8BF7\u4E00\u5206\u949F\u540E\u518D\u8BD5", 429);
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return bad("JSON \u89E3\u6790\u5931\u8D25");
  }
  const act = body.action;
  const db = await getUsersRaw();
  const users = db.users = db.users || {};
  if (act === "login") {
    const { email, hash } = body;
    if (!email || !hash) return bad("\u7F3A\u5C11\u90AE\u7BB1\u6216\u5BC6\u7801");
    const rec = users[email];
    if (!rec) return json({ ok: false, msg: "\u8BE5\u90AE\u7BB1\u5C1A\u672A\u6CE8\u518C" });
    if (rec.banned) return json({ ok: false, msg: "\u8BE5\u8D26\u53F7\u5DF2\u88AB\u5C01\u7981", banned: true });
    if (!rec.hash || rec.hash !== hash) return json({ ok: false, msg: "\u5BC6\u7801\u4E0D\u6B63\u786E" });
    return json({ ok: true, token: await issueToken(email, rec), user: stripUser(rec) });
  }
  if (act === "register") {
    const { email, hash, rec } = body;
    if (!email || !hash || !rec) return bad("\u6CE8\u518C\u4FE1\u606F\u4E0D\u5B8C\u6574");
    if (users[email]) return json({ ok: false, msg: "\u8BE5\u90AE\u7BB1\u5DF2\u6CE8\u518C\uFF0C\u8BF7\u76F4\u63A5\u767B\u5F55" });
    if (!rateLimit("reg", ip, 10, 3600 * 1e3)) return bad("\u8BE5 IP \u672C\u5C0F\u65F6\u6CE8\u518C\u6B21\u6570\u8FC7\u591A", 429);
    users[email] = rec;
    await putUsersRaw(db);
    return json({ ok: true, token: await issueToken(email, rec), user: stripUser(rec) });
  }
  if (act === "list") {
    return json({ ok: true, db: stripUsers(db) });
  }
  const tok = await verifyToken(req);
  if (!tok) return bad("\u8BF7\u5148\u767B\u5F55", 401);
  if (act === "whoami") {
    const rec = users[tok.email];
    return json({ ok: true, email: tok.email, admin: tok.email === ADMIN_EMAIL, banned: !!(rec && rec.banned) });
  }
  if (act === "saveUsers") {
    const incoming = body.users;
    if (!incoming || typeof incoming !== "object") return bad("\u7F3A\u5C11 users");
    const created = [];
    if (tok.admin) {
      Object.keys(incoming).forEach((email) => {
        if (!users[email] && incoming[email]) {
          const r = incoming[email];
          if (!r.hash) return;
          users[email] = r;
          created.push(email);
        }
      });
    }
    const FIELDS = ["nick", "title", "uid", "banned", "whips", "gs", "guest"];
    Object.keys(incoming).forEach((email) => {
      const cur = users[email];
      if (!cur) return;
      if (email !== tok.email && !tok.admin) return;
      const inc = incoming[email] || {};
      FIELDS.forEach((f) => {
        if (f in inc) cur[f] = inc[f];
      });
    });
    await putUsersRaw(db);
    return json({ ok: true, created: created.length });
  }
  if (act === "adminDel") {
    if (tok.email !== ADMIN_EMAIL) return bad("\u4EC5\u7BA1\u7406\u5458\u53EF\u6267\u884C", 403);
    if (!body.email || body.email === ADMIN_EMAIL || body.email === tok.email) return bad("\u76EE\u6807\u4E0D\u5408\u6CD5");
    if (!users[body.email]) return bad("\u8D26\u53F7\u4E0D\u5B58\u5728", 404);
    delete users[body.email];
    await putUsersRaw(db);
    return json({ ok: true });
  }
  if (act === "deleteSelf") {
    const rec = users[tok.email];
    if (!rec) return bad("\u8D26\u53F7\u4E0D\u5B58\u5728", 404);
    if (!body.hash || body.hash !== rec.hash) return bad("\u5BC6\u7801\u4E0D\u6B63\u786E\uFF0C\u6CE8\u9500\u5931\u8D25");
    delete users[tok.email];
    await putUsersRaw(db);
    return json({ ok: true });
  }
  return bad("\u672A\u77E5\u64CD\u4F5C");
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
