// netlify/functions/send-code.js
var tls = require("tls");
var crypto = require("crypto");
var SMTP_HOST = "smtp.yeah.net";
var SMTP_PORT = 465;
var FROM_NAME = "BlueprintStudio";
var SITE_NAME = "BlueprintStudio";
var CODE_TTL_MIN = 10;
var T_STEP = 6e3;
var T_TOTAL = 8500;
var ALLOW_EXACT = ["https://xiaozongzi-0530.github.io"];
var ALLOW_RE = [/^http:\/\/localhost(:\d+)?$/, /^http:\/\/127\.0\.0\.1(:\d+)?$/];
var hits = /* @__PURE__ */ new Map();
function rateLimit(ip) {
  const now = Date.now();
  const rec = hits.get(ip) || { min: [], hour: [] };
  rec.min = rec.min.filter((t) => now - t < 6e4);
  rec.hour = rec.hour.filter((t) => now - t < 36e5);
  if (rec.min.length >= 3) return "\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7 1 \u5206\u949F\u540E\u518D\u8BD5";
  if (rec.hour.length >= 10) return "\u4ECA\u5929\u83B7\u53D6\u9A8C\u8BC1\u7801\u7684\u6B21\u6570\u8FC7\u591A\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5";
  rec.min.push(now);
  rec.hour.push(now);
  hits.set(ip, rec);
  if (hits.size > 5e3) hits.clear();
  return null;
}
function corsHeaders(origin) {
  const h = {
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin"
  };
  if (origin) h["Access-Control-Allow-Origin"] = origin;
  return h;
}
function json(body, status, origin) {
  return {
    statusCode: status || 200,
    headers: Object.assign({ "Content-Type": "application/json; charset=utf-8" }, corsHeaders(origin)),
    body: JSON.stringify(body)
  };
}
function b64(s) {
  return Buffer.from(s, "utf8").toString("base64");
}
function wrap76(s) {
  return (s.match(/.{1,76}/g) || []).join("\r\n");
}
function encodeHeader(s) {
  return "=?UTF-8?B?" + b64(s) + "?=";
}
function dotStuff(s) {
  return s.replace(/\r\n\./g, "\r\n..").replace(/^\./, "..");
}
function readReplyFactory(sock) {
  let buf = "";
  const waiters = [];
  function tryParse() {
    let pos = 0;
    let code = null;
    let endPos = -1;
    for (; ; ) {
      const nl = buf.indexOf("\r\n", pos);
      if (nl < 0) return null;
      const line = buf.slice(pos, nl);
      if (!/^\d{3}([ -]|$)/.test(line)) return null;
      if (code === null) code = parseInt(line.slice(0, 3), 10);
      pos = nl + 2;
      if (line.length === 3 || line[3] !== "-") {
        endPos = pos;
        break;
      }
    }
    if (endPos < 0) return null;
    const text = buf.slice(0, endPos).replace(/\r\n$/, "").replace(/\r\n/g, " | ");
    buf = buf.slice(endPos);
    return { code, text };
  }
  sock.on("data", (d) => {
    buf += d.toString("utf8");
    for (; ; ) {
      if (!waiters.length) break;
      const r = tryParse();
      if (!r) break;
      waiters.shift()(null, r);
    }
  });
  sock.on("error", (e) => {
    while (waiters.length) waiters.shift()(e);
  });
  sock.on("close", () => {
    while (waiters.length) waiters.shift()(new Error("\u8FDE\u63A5\u5DF2\u5173\u95ED"));
  });
  return function readReply(timeout) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("SMTP \u54CD\u5E94\u8D85\u65F6")), timeout || T_STEP);
      waiters.push((err, r) => {
        clearTimeout(timer);
        if (err) reject(err);
        else resolve(r);
      });
    });
  };
}
function buildMessage(to, code) {
  const boundary = "bs_" + crypto.randomBytes(8).toString("hex");
  const subject = SITE_NAME + " \u90AE\u7BB1\u9A8C\u8BC1\u7801";
  const text = "\u4F60\u597D\uFF0C\n\n\u4F60\u7684 " + SITE_NAME + " \u9A8C\u8BC1\u7801\u662F\uFF1A " + code + "\n\n\u6709\u6548\u671F " + CODE_TTL_MIN + " \u5206\u949F\u3002\u82E5\u975E\u672C\u4EBA\u64CD\u4F5C\uFF0C\u8BF7\u5FFD\u7565\u672C\u90AE\u4EF6\u3002\n";
  const html = '<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;font-size:15px;color:#111"><p>\u4F60\u597D\uFF0C</p><p>\u4F60\u7684 ' + SITE_NAME + ' \u9A8C\u8BC1\u7801\u662F\uFF1A</p><p style="font-size:30px;font-weight:700;letter-spacing:8px;margin:18px 0;color:#2b5cff">' + code + "</p><p>\u6709\u6548\u671F " + CODE_TTL_MIN + ' \u5206\u949F\u3002\u82E5\u975E\u672C\u4EBA\u64CD\u4F5C\uFF0C\u8BF7\u5FFD\u7565\u672C\u90AE\u4EF6\u3002</p><p style="color:#888;font-size:12px;margin-top:24px">\u6B64\u90AE\u4EF6\u7531\u7CFB\u7EDF\u81EA\u52A8\u53D1\u9001\uFF0C\u8BF7\u52FF\u76F4\u63A5\u56DE\u590D\u3002</p></div>';
  const head = [
    'From: "' + encodeHeader(FROM_NAME) + '" <' + process.env.SMTP_USER + ">",
    "To: <" + to + ">",
    "Subject: " + encodeHeader(subject),
    "Date: " + (/* @__PURE__ */ new Date()).toUTCString().replace("GMT", "+0000"),
    "Message-ID: <" + crypto.randomBytes(12).toString("hex") + "@yeah.net>",
    "MIME-Version: 1.0",
    'Content-Type: multipart/alternative; boundary="' + boundary + '"'
  ].join("\r\n");
  const body = "\r\n\r\n--" + boundary + "\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" + wrap76(b64(text)) + "\r\n--" + boundary + "\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" + wrap76(b64(html)) + "\r\n--" + boundary + "--\r\n";
  return head + body;
}
function sendMail(to, code) {
  return new Promise((resolve, reject) => {
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;
    if (!user || !pass) {
      return reject(new Error("\u670D\u52A1\u7AEF\u672A\u914D\u7F6E SMTP_USER / SMTP_PASS"));
    }
    let stage = "\u8FDE\u63A5";
    let done = false;
    const sock = tls.connect({ host: SMTP_HOST, port: SMTP_PORT, servername: SMTP_HOST });
    sock.setTimeout(T_STEP);
    const finish = (err) => {
      if (done) return;
      done = true;
      clearTimeout(killer);
      try {
        sock.destroy();
      } catch (_) {
      }
      if (err) reject(err);
      else resolve();
    };
    const killer = setTimeout(() => finish(new Error(stage + "\u9636\u6BB5\u8D85\u65F6\uFF08" + T_TOTAL / 1e3 + " \u79D2\uFF09")), T_TOTAL);
    sock.on("error", (e) => finish(new Error(stage + "\u5931\u8D25\uFF1A" + e.message)));
    sock.on("timeout", () => finish(new Error(stage + "\u8D85\u65F6\uFF0C\u670D\u52A1\u5668\u65E0\u54CD\u5E94")));
    const read = readReplyFactory(sock);
    async function expect(want, name) {
      stage = name;
      const r = await read();
      const ok = Array.isArray(want) ? want.includes(r.code) : r.code === want;
      if (!ok) throw new Error(name + "\u5931\u8D25(" + r.code + ")\uFF1A" + String(r.text).slice(0, 140));
      return r;
    }
    const write = (s) => new Promise((res, rej) => sock.write(s + "\r\n", (e) => e ? rej(e) : res()));
    sock.on("secureConnect", async () => {
      try {
        await expect(220, "\u7B49\u5F85\u670D\u52A1\u5668\u6B22\u8FCE\u8BED");
        await write("EHLO blueprintstudio");
        await expect(250, "\u63E1\u624B");
        await write("AUTH LOGIN");
        await expect(334, "\u8BA4\u8BC1");
        await write(b64(user));
        await expect(334, "\u8BA4\u8BC1");
        await write(b64(pass));
        await expect(235, "\u767B\u5F55");
        await write("MAIL FROM:<" + user + ">");
        await expect(250, "\u53D1\u4EF6\u4EBA");
        await write("RCPT TO:<" + to + ">");
        await expect([250, 251], "\u6536\u4EF6\u4EBA");
        await write("DATA");
        await expect(354, "\u51C6\u5907\u6B63\u6587");
        await write(dotStuff(buildMessage(to, code)) + "\r\n.");
        await expect(250, "\u6295\u9012");
        stage = "\u9000\u51FA";
        await write("QUIT").catch(() => {
        });
        finish(null);
      } catch (e) {
        finish(e);
      }
    });
  });
}
exports.handler = async function(event) {
  const origin = event.headers && (event.headers.origin || event.headers.Origin) || "";
  const allowed = !origin || ALLOW_EXACT.includes(origin) || ALLOW_RE.some((re) => re.test(origin));
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: corsHeaders(allowed ? origin : ""), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return json({ ok: false, message: "\u53EA\u652F\u6301 POST" }, 405, allowed ? origin : "");
  }
  if (!allowed) {
    return json({ ok: false, message: "\u6765\u6E90\u4E0D\u88AB\u5141\u8BB8" }, 403, "");
  }
  let payload = {};
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (_) {
    return json({ ok: false, message: "\u8BF7\u6C42\u683C\u5F0F\u9519\u8BEF" }, 400, origin);
  }
  const email = String(payload.email || "").trim().toLowerCase();
  const code = String(payload.code || "").trim();
  if (!/^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/.test(email) || email.length > 120) {
    return json({ ok: false, message: "\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E" }, 400, origin);
  }
  if (!/^[1-9]\d{5}$/.test(code)) {
    return json({ ok: false, message: "\u9A8C\u8BC1\u7801\u683C\u5F0F\u4E0D\u6B63\u786E" }, 400, origin);
  }
  const ip = event.headers && (event.headers["x-nf-client-connection-ip"] || event.headers["x-forwarded-for"]) || "unknown";
  const limited = rateLimit(String(ip).split(",")[0].trim());
  if (limited) {
    return json({ ok: false, message: limited }, 429, origin);
  }
  try {
    await sendMail(email, code);
    console.log("[send-code] ok ->", email);
    return json({ ok: true }, 200, origin);
  } catch (e) {
    console.error("[send-code] fail ->", email, e && e.message);
    const msg = String(e && e.message || "");
    const human = /未配置/.test(msg) ? "\u670D\u52A1\u7AEF\u672A\u5B8C\u6210\u914D\u7F6E\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458" : /登录失败/.test(msg) ? "\u90AE\u7BB1\u767B\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" : /超时/.test(msg) ? "\u53D1\u4FE1\u8D85\u65F6\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" : "\u90AE\u4EF6\u53D1\u9001\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5";
    return json({ ok: false, message: human }, 502, origin);
  }
};
